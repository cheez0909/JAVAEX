package ex01;

public class SceduleMain {
    public static void main(String[] args) {
        Schedule sc = new Schedule();
        sc.setYear(2023);
        sc.setMonth(11);
        sc.setDay(33);

        System.out.println(sc);
    }
}
